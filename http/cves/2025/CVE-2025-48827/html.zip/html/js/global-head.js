/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.7.5
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2023 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
(()=>{function f(a,c){var b=d;a=a.split(".");for(var e=0;e<a.length-1;e++)b=b[a[e]]=b[a[e]]||{};return b[a[e]]=b[a[e]]||c||{}}var d=vBulletin={};d.ensureObj=f;d.ensureFun=a=>"function"==typeof a?a:()=>{};d.ensureMethod=(a,c)=>d.ensureFun(a[c]).bind(a);f("Responsive.Debounce").checkBrowserSize=()=>{if(Modernizr){var a=document.body;a.classList.toggle("l-xsmall",Modernizr.mq("(max-width: 479px)"));a.classList.toggle("l-small",Modernizr.mq("(max-width: 767px)"));a.classList.toggle("l-desktop",
Modernizr.mq("(min-width: 768px)"))}};var h=f("phrase.precache",[]),k=f("options.precache",[]);d.precache=function(a,c){h.push(...a);k.push(...c)};var g={};d.ready=function(a){if(!(a in g)){var c,b=new Promise((a,b)=>{c=a});b.resolve=c;g[a]=b}return g[a]}})();
