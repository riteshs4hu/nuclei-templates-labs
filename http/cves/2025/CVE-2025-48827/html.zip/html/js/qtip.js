/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.7.5
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2023 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
vBulletin.precache(["no_preview_text_available","working_ellipsis"],["threadpreview"]);
vBulletin.qtip=function(b){function d(a,c,d){var g=["left","right"];vBulletin.isRtl()&&g.reverse();c={style:{classes:"qtip-shadow qtip-rounded "+c},position:{my:"top "+g[0],at:"bottom "+g[1],viewport:b(window)}};b.extend(c,d);a.qtip(c)}function h(a){d(b(".js-tooltip[title]",a))}(function(){function a(a,c){var e=c.elements.tooltip;window.setTimeout(function(){var a=parseInt(e.css("left"),10),c=b(window).scrollLeft();if(a<c)e.css("left",c+1);else{var f=e.outerWidth(),d=b(window).width();f=a+f;c+=d;
f>c&&e.css("left",a-(f-c)-1)}},0)}var c=b.fn.qtip;b.fn.qtip=function(){"object"==typeof arguments[0]&&("undefined"==typeof arguments[0].events&&(arguments[0].events={}),arguments[0].events.move="function"==typeof arguments[0].events.move?vBulletin.ajaxtools.runBeforeCallback(arguments[0].events.move,a):a);return c.apply(this,arguments)}})();h(b(document));b(document).on("vb-instrument",function(a){h(b(a.target))});(0<b(".channel-content-widget").length&&b(".channel-content-widget").eq(0).attr("data-canviewtopiccontent")||
0<b(".search-results-widget").length)&&b(document).offon("mouseover",".topic-list-container .topic-title, .conversation-list .post-title, .conversation-list .b-post__title",function(){if(0<vBulletin.options.get("threadpreview")){var a=b(this);if("1"!=a.data("vb-qtip-preview-initialized")){a.data("vb-qtip-preview-initialized","1");var c=parseInt(a.closest(".topic-item").attr("data-node-id")||a.closest(".js-post").attr("data-node-id"));vBulletin.isRtl();d(a,"qtip-topicpreview",{content:{text:function(a,
d){var e=function(a){var b=a?a:vBulletin.phrase.get("no_preview_text_available");d.set("content.text",b);return a};return c?(vBulletin.AJAX({call:"/ajax/fetch-node-preview",data:{nodeid:c},success:function(a){e(b.trim(a))},api_error:function(){e()},error:function(a,b,c){e(b+": "+c)}}),vBulletin.phrase.get("working_ellipsis")):e()}},show:{delay:500},hide:{event:"mouseleave click"}});a.trigger("mouseover")}}else b(document).off("mouseover",".topic-list-container .topic-title, .conversation-list .post-title, .conversation-list .b-post__title")});
return{apply:d}}(jQuery);
