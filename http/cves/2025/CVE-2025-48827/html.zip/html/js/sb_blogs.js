/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.7.5
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2023 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
vBulletin.precache(["create_a_blog","error_creating_user_blog_channel","error_fetching_user_blog_channels","select_a_blog"],[]);
(function(a){function b(b){var g=a(this).closest(".canvas-widget").data("blog-channel-id");vBulletin.AJAX({call:"/ajax/api/user/getGitCanStart",data:{parentNodeId:g},success:function(c){if(a.isArray(c)){var b=c.length;if(1<b){var e=a("#user-blogs-dialog"),f=a("select.custom-dropdown",e);a.each(c,function(b,d){a("<option />").val(d.nodeid).html(d.title).appendTo(f)});e.dialog({title:vBulletin.phrase.get("select_a_blog"),autoOpen:!1,modal:!0,resizable:!1,closeOnEscape:!1,showCloseButton:!1,width:500,
dialogClass:"dialog-container create-blog-dialog-container dialog-box",open:function(){f.removeClass("h-hide").selectBox()},close:function(){f.selectBox("destroy").find("option").remove()},create:function(){a(".btnContinue",this).on("click",function(){location.href="{0}/new-content/{1}".format(pageData.baseurl,a("select.custom-dropdown",e).val())});a(".btnCancel",this).on("click",function(){e.dialog("close")})}}).dialog("open")}else 1==b?location.href="{0}/new-content/{1}".format(pageData.baseurl,
c[0].nodeid):vBulletin.AJAX({call:"/ajax/api/blog/canCreateBlog",data:{parentid:g},success:function(b){var d=a("#create-blog-dialog").dialog({title:vBulletin.phrase.get("create_a_blog"),autoOpen:!1,modal:!0,resizable:!1,closeOnEscape:!1,showCloseButton:!1,width:500,dialogClass:"dialog-container create-blog-dialog-container dialog-box",create:function(){vBulletin.ajaxForm.apply(a("form",this),[{success:function(b,d,c,e){a.isPlainObject(b)&&0<Number(b.nodeid)?location.href="{0}/new-content/{1}".format(pageData.baseurl,
b.nodeid):vBulletin.error("error","error_creating_user_blog_channel")},error_phrase:"error_creating_user_blog_channel"}]);a(".btnCancel",this).on("click",function(){d.dialog("close")});a(".blog-adv-settings",this).on("click",function(){var b=a.trim(a(".blog-title",d).val()),c=a.trim(a(".blog-desc",d).val());return b||c?(location.href="{0}?blogtitle={1}&blogdesc={2}".format(this.href,encodeURIComponent(b),encodeURIComponent(c)),!1):!0})},open:function(){a("form",this).trigger("reset")}}).dialog("open")},
title_phrase:"create_a_blog"})}else vBulletin.error("error","error_fetching_user_blog_channels")},error_phrase:"error_fetching_user_blog_channels"})}if(!vBulletin.pageHasSelectors([".bloghome-widget"]))return!1;a(function(){a(".bloghome-widget").offon("click",".conversation-toolbar .new-conversation-btn",b);vBulletin.memberChannel.initFlexGridAdjustments(a(".bloghome-widget"))})})(jQuery);
