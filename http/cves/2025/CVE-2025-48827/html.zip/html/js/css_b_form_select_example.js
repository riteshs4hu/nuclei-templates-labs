(function(a){a(document).ready(function(){a(".js-drop-down-example").selectBox()})})(jQuery);
