/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.7.5
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2023 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
vBulletin.createStorageTools=function(e,n,p){function d(a){if(!a.loaded){a.loaded=!0;try{var b=localStorage.getItem(e+a.name);if(b)if(b=JSON.parse(b),a.istimed){a.cache.values=b.values||a.cache.values;a.cache.times=b.times||a.cache.times;b=!1;var c=a.cache.values,f=a.cache.times,d;for(d in c)f[d]<a.latest&&(delete c[d],delete f[d],b=!0);b&&g(a)}else a.cache.values=b}catch(q){}}}function g(a){try{var b=e+a.name,c=a.cache;a.istimed||(c=c.values);localStorage.removeItem(b);localStorage.setItem(b,
JSON.stringify(c))}catch(f){}}function h(a,b,c,d){this.loaded=!1;this.name=a;this.cache={values:{},times:{}};if(this.istimed=!!b)this.latest=c,this.current=d}function k(a,b,c){var d={path:n,domain:p};c&&(!0===c&&(c=365),d.expires=c);$.cookie(e+a,b,d)}function l(a){return $.cookie(e+a)}function m(a,b){this.name=a;this.permanent=b;try{var c=l(a);c&&(this.cache=JSON.parse(c))}catch(f){}this.cache=this.cache||{}}try{localStorage.removeItem("vbcache-")}catch(a){}h.prototype={get:function(a){d(this);var b=
this.cache.values;return b.hasOwnProperty(a)?b[a]:null},getAll:function(){d(this);return this.cache.values},isSet:function(a){d(this);return this.cache.values.hasOwnProperty(a)},set:function(a,b){d(this);var c=a;$.isPlainObject(a)||(c={},c[a]=b);for(_key in c)this.cache.values[_key]=c[_key],this.istimed&&(this.cache.times[_key]=this.current);g(this)},unset:function(a){d(this);delete this.cache.values[a];delete this.cache.times[a];g(this)}};m.prototype={get:function(a,b){return this.cache.hasOwnProperty(a)?
this.cache[a]:void 0!==b?b:null},getAll:function(){return this.cache},set:function(a,b){this.cache[a]=b;k(this.name,JSON.stringify(this.cache),this.permanent)},unset:function(a){delete this.cache[a];k(this.name,JSON.stringify(this.cache),this.permanent)}};return{createStorage:a=>new h(a),createStorageTimed:(a,b,c)=>new h(a,!0,b,c),createArrayCookie:(a,b)=>new m(a,b),setCookie:k,getCookie:l}};
