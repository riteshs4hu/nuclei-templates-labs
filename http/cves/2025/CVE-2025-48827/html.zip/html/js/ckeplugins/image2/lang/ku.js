/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'ku', {
	alt: 'جێگرەوەی دەق',
	btnUpload: 'ناردنی بۆ ڕاژه',
	captioned: 'وێنەی بەسەردێر',
	captionPlaceholder: 'سەردێر',
	infoTab: 'زانیاری وێنه',
	lockRatio: 'داخستنی ڕێژه',
	menu: 'خاسیەتی وێنه',
	pathName: 'وێنە',
	pathNameCaption: 'سەردێر',
	resetSize: 'ڕێکخستنەوەی قەباره',
	resizer: 'کرتەبکە و ڕایبکێشە بۆ قەبارە گۆڕین',
	title: 'خاسیەتی وێنه',
	uploadTab: 'بارکردن',
	urlMissing: 'سەرچاوەی بەستەری وێنه بزره',
	altMissing: 'جێگرەوەی دەق لەدەست چووە.'
} );
