/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'hu', {
	alt: 'Alternatív szöveg',
	btnUpload: 'Küldés a szerverre',
	captioned: 'Feliratozott kép',
	captionPlaceholder: 'Képfelirat',
	infoTab: 'Alaptulajdonságok',
	lockRatio: 'Arány megtartása',
	menu: 'Kép tulajdonságai',
	pathName: 'kép',
	pathNameCaption: 'felirat',
	resetSize: 'Eredeti méret',
	resizer: 'Kattintson és húzza az átméretezéshez',
	title: 'Kép tulajdonságai',
	uploadTab: 'Feltöltés',
	urlMissing: 'Hiányzik a kép URL-je',
	altMissing: 'Az alternatív szöveg hiányzik.'
} );
