/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.7.5
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2023 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
(function(c){function d(a){c(".humanverify_image",a).each(function(){var b=c(this),a=c(".refresh_imagereg",b);a.off("click").on("click",b,e);c(".imagereg",b).off("click").on("click",b,e);a.removeClass("h-hide")})}function e(a){var b=a.data;c(".progress_imagereg",b).removeClass("h-hide");vBulletin.AJAX({call:"/ajax/api/hv/generateToken",success:function(a){a=a.hash;c("input.hash",b).val(a);c(".imagereg",b).attr("src",pageData.baseurl+"/hv/image?hash="+a);c(".imageregt",b).val("")},api_error:function(){},
complete:function(){c(".progress_imagereg",b).addClass("h-hide")}});return!1}vBulletin.ensureObj("hv");vBulletin.hv.resetOnError=function(a,b,c){var f=vBulletin.ajaxtools;return f.hasError(a,/humanverify_.*_wronganswer/)?(c.after_error=vBulletin.ajaxtools.runBeforeCallback(c.after_error,function(){vBulletin.hv.reset(!0)}),f.showApiError(a,b,c),!1):!0};vBulletin.hv.reset=function(a){var b=c(".humanverify.humanverify_image");if(0<b.length)b.find(".refresh_imagereg").trigger("click"),a&&b.find(".imageregt").trigger("focus");
else if(0<c(".js-humanverify-recaptcha2").length&&"undefined"!=typeof grecaptcha&&"function"==typeof grecaptcha.reset)grecaptcha.reset();else{var d=c(".humanverify.humanverify_question");0<d.length&&vBulletin.AJAX({call:"/ajax/render/humanverify",data:{action:"register",isAjaxTemplateRenderWithData:!0},success:function(b){b=c(b.template);d.replaceWith(b);a&&b.find(".answer").trigger("focus")}})}};vBulletin.hv.show=function(a){var b=a.find(".imagereg");a.removeClass("h-hide");b.height()!=b.attr("height")&&
a.find(".refresh_imagereg").trigger("click")};vBulletin.hv.init=function(a){d(a)};window.recaptcha2callback=function(a){c(".js-humanverify-recaptcha2-response").val(a)};c(function(){d(c(document))})})(jQuery);
