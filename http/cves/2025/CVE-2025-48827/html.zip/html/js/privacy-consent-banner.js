/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.7.5
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2023 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
vBulletin.precache([],["privacy_consent_cookie_name","privacyurl"]);
(function(b){function f(a){b(a.target).closest(".js-privacy-consent-banner__banner").length||a.preventDefault()}function g(a){var c=Math.max(document.documentElement.clientWidth,window.innerWidth||0);h=Math.max(document.documentElement.clientHeight,window.innerHeight||0);c&&415>=c||h&&415>=h||c&&h&&650>=c&&650>=h?(a.data("restore-position-class")||b.each(["b-modal-banner__banner--top","b-modal-banner__banner--center","b-modal-banner__banner--bottom","b-modal-banner__banner--cover"],function(b,c){a.is("."+
c)&&a.data("restore-position-class",c)}),a.removeClass("b-modal-banner__banner--top b-modal-banner__banner--center b-modal-banner__banner--bottom b-modal-banner__banner--cover").addClass("b-modal-banner__banner--cover")):a.removeClass("b-modal-banner__banner--cover").addClass(a.data("restore-position-class"))}function k(){function a(a){a.stopPropagation()}var c=b(".js-privacy-consent-banner__banner"),d=b(".js-privacy-consent-banner__overlay");c.off("click",a).on("click",a);d.off("click",a).on("click",
a);g(c);c.removeClass("h-hide-imp");d.removeClass("h-hide-imp");b("html, body").addClass("b-modal-banner--disabled");try{document.addEventListener("touchmove",f,{capture:!0,passive:!1})}catch(r){}b(window).off("resize orientationchange",e).on("resize orientationchange",e)}function n(){var a=b(".js-privacy-consent-banner__banner"),c=b(".js-privacy-consent-banner__overlay");a.remove();c.remove();b("html, body").removeClass("b-modal-banner--disabled");try{document.removeEventListener("touchmove",f,{capture:!0,
passive:!1})}catch(q){}b(window).off("resize orientationchange",e)}function l(){var a=Math.round((new Date).getTime()/1E3);b.cookie(d.cookieName,"CONSENTED:"+a,{path:pageData.cookie_path,domain:pageData.cookie_domain,expires:d.cookieExpireDays});n();vBulletin.AJAX({call:"/ajax/api/user/updateGuestPrivacyConsent",data:{consent:1},success:function(){}});return!1}function p(){if(!(0<pageData.userid)&&"0"!=pageData.privacystatus){var a=vBulletin.options.get("privacy_consent_cookie_name");d.cookieName=
""!=a?a:pageData.cookie_prefix+"privacy_consent_guest";a=b.cookie(d.cookieName);if(!a||a.match(/^NOTINEU:/))a=vBulletin.options.get("privacyurl"),a&&vBulletin.getAbsoluteUrl(a)==vBulletin.getAbsoluteUrl(document.location.href)||(b(".js-privacy-consent-banner__banner .js-privacy-consent-banner__button").off("click",l).on("click",l),k())}}var d={cookieName:"",cookieExpireDays:3650},e=b.debounce(100,function(a){g(b(".js-privacy-consent-banner__banner"))});if("2"==pageData.privacystatus){k();var m=!0}else m=
!1;m||p()})(jQuery);
