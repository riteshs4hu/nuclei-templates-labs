/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.7.5
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2023 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
vBulletin.createSiteDataTools=function(p){function g(){var a=[],b=[];(new Set(h)).forEach(function(d){a.push(d)});a=a.filter(function(a){return!k.isSet(a)});(new Set(l)).forEach(function(a){b.push(a)});b=b.filter(function(a){return!m.isSet(a+n)});vBulletin.loadingIndicator.suppressNextAjaxIndicator();$.ajax({url:p+"/ajax/loaddata",async:!1,data:{options:a,phrases:b},type:"POST",dataType:"json",success:function(d){if(d&&!d.hasOwnProperty("errors")){h.length=0;l.length=0;var c={},e=d.options;
$.each(a,function(a,b){c[b]=e.hasOwnProperty(b)?e[b]:null});k.set(c);var f={},g=d.phrases;$.each(b,function(a,b){f[b+n]=g.hasOwnProperty(b)?g[b]:b});m.set(f)}else console.warn("Unexpected result when fetching options",d)},error:function(a,b,c){console.warn("Error when fetching options: {0}".format(c))}})}var f={},m,l,c,n,e={},k,h;f.init=function(a,b,d,e){c=a;n="-"+b;m=d;l=e};f.get=function(){if(1>arguments.length)return console.log("vBulletin.phrase.get() called with no parameters"),"";var a=arguments;
Array.isArray(a[0])&&(a=a[0]);var b=a[0]+n;m.isSet(b)||(l.push(a[0]),g());var d=m.get(b);if(!d)return b;d=d.replace(/\{sitename\}/g,e.get("bbtitle")).replace(/\{musername\}/g,c.musername).replace(/\{username\}/g,c.username).replace(/\{userid\}/g,c.userid).replace(/\{registerurl\}/g,c.registerurl).replace(/\{activationurl\}/g,c.activationurl).replace(/\{helpurl\}/g,c.helpurl).replace(/\{contacturl\}/g,c.contacturl).replace(/\{homeurl\}/g,c.baseurl).replace(/\{date\}/g,c.datenow).replace(/\{register_page\}/g,
c.registerurl).replace(/\{activation_page\}/g,c.activationurl).replace(/\{help_page\}/g,c.helpurl).replace(/\{sessionurl\}/g,"").replace(/\{sessionurl_q\}/g,"");for(b=1;b<a.length;++b)d=d.replace(new RegExp("%"+b+"\\$s","gm"),a[b]);return d};f.register=function(a){$.merge(l,$.makeArray(a))};e.init=function(a,b){k=a;h=b};e.get=function(a){k.isSet(a)||(h.push(a),g(a));return k.get(a)};e.register=function(a){$.merge(h,$.makeArray(a))};return{phrase:f,options:e}};
